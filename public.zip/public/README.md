#CityExplorer
This is a Sencha Touch 2 app open-sourced used in my coming Sencha Touch 2 book in french, as a tutorial

@flrent
